#!/bin/bash
cd "$(dirname "$0")"
/Users/mac/Desktop/OpenCode_Projects/glm-project/stock-app/.venv/bin/python3 app.py --open-browser
