@echo off
cd /d "%~dp0"
start "" stock-app.exe --open-browser
